// ============================
// DATA
// ============================
const menuData = [
  { size: '8"',  pax: '2–3 pax',   price: '₱200',   bestseller: false },
  { size: '9"',  pax: '4–5 pax',   price: '₱300',   bestseller: false },
  { size: '10"', pax: '6–8 pax',   price: '₱400',   bestseller: false },
  { size: '11"', pax: '9–10 pax',  price: '₱500',   bestseller: false },
  { size: '12"', pax: '11–12 pax', price: '₱600',   bestseller: true  },
  { size: '13"', pax: '13–14 pax', price: '₱700',   bestseller: false },
  { size: '14"', pax: '15–18 pax', price: '₱900',   bestseller: false },
  { size: '15"', pax: '19–20 pax', price: '₱1,100', bestseller: false },
  { size: '16"', pax: '21–25 pax', price: '₱1,300', bestseller: false },
  { size: '18"', pax: '26–30 pax', price: '₱1,500', bestseller: true  },
];

const galleryItems = [
  { src: 'images/gallery1.png', caption: 'Freshly made — loaded with shrimp, eggs & chicharon', tag: 'Bilao' },
  { src: 'images/gallery2.png', caption: 'Ready for your celebration! 🎉', tag: 'Party Size' },
  { src: 'images/gallery3.png', caption: 'Authentic Pancit Malabon — order yours today', tag: 'Bilao' },
  { src: 'images/food.png',     caption: 'Classic Pancit Malabon — rich orange sauce goodness', tag: 'Signature' },
  { src: 'images/img2247.png',  caption: 'Made fresh every order — never reheated', tag: 'Fresh Daily' },
  { src: 'images/img2248.png',  caption: 'Perfect for family gatherings & parties', tag: 'Family Size' },
];

const toppingsData = [
  { icon: '🦐', title: 'Fresh Shrimp',    desc: 'Plump, juicy shrimp generously placed on every bilao' },
  { icon: '🥚', title: 'Halved Eggs',     desc: 'Classic hard-boiled eggs, perfectly halved' },
  { icon: '🐟', title: 'Tinapa Flakes',   desc: 'Smoky smoked fish flakes for that authentic flavor' },
  { icon: '🧅', title: 'Chicharon',       desc: 'Crispy pork rinds for satisfying crunch' },
  { icon: '🌿', title: 'Spring Onions',   desc: 'Fresh green onions for color and freshness' },
  { icon: '🍊', title: 'Special Sauce',   desc: 'Our signature rich annatto-based orange sauce' },
];

const branchData = [
  {
    name: 'Parang Branch',
    address: '5 G. Del Pilar St., Parang, Marikina City',
    phones: ['0969-4941-518', '0927-857-2528'],
    map: 'https://www.google.com/maps/@14.6567176,121.114458,3a,75y,211.82h,97.63t/data=!3m7!1e1!3m5!1s_mZm6C71blTtLhhWujXwgQ!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fcb_client%3Dmaps_sv.tactile%26w%3D900%26h%3D600%26pitch%3D-7.630287251339922%26panoid%3D_mZm6C71blTtLhhWujXwgQ%26yaw%3D211.82163830924412!7i16384!8i8192?entry=ttu&g_ep=EgoyMDI2MDYwMy4xIKXMDSoASAFQAw%3D%3D',
  },
  {
    name: 'SSS Vill Branch',
    address: '72 Panorama St. SSS Vill. Concepcion Dos, Marikina City',
    phones: ['0927-1824-202', '0999-3339-527'],
    map: 'https://www.google.com/maps/place/Parjuan\'s+Pancit+Malabon+House/@14.6393705,121.1279048,3a,51.1y,149.27h,89.68t/data=!3m7!1e1!3m5!1sU0TjuzTdwXQlIzCB5ZFsZw!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fcb_client%3Dmaps_sv.tactile%26w%3D900%26h%3D600%26pitch%3D0.3182449498675055%26panoid%3DU0TjuzTdwXQlIzCB5ZFsZw%26yaw%3D149.270972575488!7i16384!8i8192!4m6!3m5!1s0x3397b9f139fc1371:0xb473b985ea1b6025!8m2!3d14.6393145!4d121.1279501!16s%2Fg%2F11pz3vkhvm?entry=ttu&g_ep=EgoyMDI2MDYwMy4xIKXMDSoASAFQAw%3D%3D',
  },
  {
    name: 'Tumana Branch',
    address: 'Bagong Farmers Avenue 1 St., Brgy. Tumana, Marikina City',
    phones: ['0969-4941-518', '0927-857-2528'],
    map: 'https://maps.google.com/?q=Tumana+Marikina+City',
  },
  {
    name: 'San Mateo Branch',
    address: 'Lot 2 Blk 31 Rose St. Modesta Village, Santo Niño, San Mateo',
    phones: ['0969-4941-518'],
    map: 'https://maps.google.com/?q=Modesta+Village+San+Mateo+Rizal',
  },
];

const testimonialData = [
  { text: 'Masarap at sulit! Lagi na kaming nag-oorder dito kapag may birthday sa pamilya. Hindi mapapantayan ang luto!', name: 'Maria Santos', loc: 'Parang, Marikina', emoji: '👩' },
  { text: 'Perfect for family gatherings! Malaki ang bilao at maraming toppings. Lahat ng bisita namin ay nagustuhan!', name: 'Jun Reyes', loc: 'Concepcion, Marikina', emoji: '👨' },
  { text: 'Affordable and delicious — the best combination! Subok na ito ng maraming handaan namin. Always on time ang delivery!', name: 'Ana Dela Cruz', loc: 'Tumana, Marikina', emoji: '👩' },
  { text: 'Favorite Pancit Malabon in Marikina! Ang sarap ng sauce — hindi tuyo, hindi matubig. Perpekto talaga!', name: 'Carlo Bautista', loc: 'San Mateo, Rizal', emoji: '👨' },
  { text: 'Pinaka-sulit na bilao sa buong Marikina! Lagi kaming bumabalik. Highly recommended sa lahat ng may event!', name: 'Rosie Mendoza', loc: 'Marikina City', emoji: '👩' },
];

const marqueeItems = [
  '🍜 Authentic Pancit Malabon',
  '🦐 Fresh Seafood Toppings',
  '🎉 Perfect for Celebrations',
  '🛵 Pickup & Delivery',
  '💰 Starting at ₱200',
  '📍 4 Branches in Marikina & San Mateo',
];

// ============================
// HELPERS
// ============================
const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const MESSENGER = 'https://m.me/ParjuansPancitMalabon';
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const peso = n => '₱' + n.toLocaleString('en-PH');
const priceNum = p => parseInt(p.replace(/[^\d]/g, ''), 10);
const paxRange = p => { const m = p.match(/(\d+)\D+(\d+)/); return [+m[1], +m[2]]; };
const groupOf = max => (max <= 8 ? 'small' : max <= 20 ? 'medium' : 'large');
const store = {
  get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}

// ============================
// PAGE NAVIGATION (with back-button support)
// ============================
const PAGES = ['home', 'services', 'menu', 'gallery', 'about', 'branches', 'contact'];

function showPage(name, opts = {}) {
  if (!PAGES.includes(name)) name = 'home';
  $$('.page').forEach(p => p.classList.remove('active'));
  $('#page-' + name).classList.add('active');
  window.scrollTo({ top: 0, behavior: opts.instant ? 'auto' : 'smooth' });
  setTimeout(initReveal, 100);
  $$('.nav-links button, .mobile-menu button').forEach(btn => {
    const m = (btn.getAttribute('onclick') || '').match(/showPage\('(\w+)'/);
    btn.classList.toggle('active-page', !!m && m[1] === name);
  });
  document.title = (name === 'home' ? '' : name[0].toUpperCase() + name.slice(1) + ' · ') + "Parjuan's Pancit Malabon House";
  if (!opts.fromHash && location.hash !== '#' + name) history.pushState(null, '', '#' + name);
  closeMobile();
  if (name === 'home') runCountUp();
}
window.addEventListener('popstate', () => showPage(location.hash.slice(1) || 'home', { fromHash: true, instant: true }));

// ============================
// MARQUEE / TOPPINGS / STATIC RENDERS
// ============================
function renderMarquee() {
  const el = $('#marqueeInner');
  if (!el) return;
  el.innerHTML = [...marqueeItems, ...marqueeItems].map(i => `<span class="marquee-item">${i}<span class="marquee-dot"></span></span>`).join('');
}
function renderToppings() {
  const grid = $('#toppingsGrid');
  if (!grid) return;
  grid.innerHTML = toppingsData.map(t => `
    <div class="topping-card"><div class="topping-icon">${t.icon}</div>
    <h3 class="topping-title">${t.title}</h3><p class="topping-desc">${t.desc}</p></div>`).join('');
}

// ============================
// MENU + ORDER CART
// ============================
let cart = store.get('parjuans_cart', {}); // { '12"': qty }
const sizeInfo = size => menuData.find(m => m.size === size);

function renderMenu() {
  const grid = $('#menuGrid');
  if (!grid) return;
  grid.innerHTML = menuData.map((item, i) => {
    const [min, max] = paxRange(item.pax);
    return `
    <div class="menu-card" data-size='${item.size}' data-group="${groupOf(max)}" data-min="${min}" data-max="${max}" style="animation-delay:${i * 0.05}s">
      <div class="menu-card-img">
        ${item.bestseller ? '<span class="bestseller-badge">⭐ Best</span>' : ''}
        <img src="images/food.png" alt="Pancit Malabon ${item.size}" loading="lazy" />
      </div>
      <div class="menu-card-body">
        <div class="menu-card-size">Bilao ${item.size}</div>
        <div class="menu-card-pax">👥 ${item.pax}</div>
        <div class="menu-card-price">${item.price} <span>/ bilao</span></div>
        <div class="menu-card-actions">
          <button class="menu-card-btn add-btn pulse-btn" data-add>➕ Add to Order</button>
          <div class="qty"><button data-dec aria-label="Less">−</button><span data-q>0</span><button data-inc aria-label="More">+</button></div>
        </div>
      </div>
    </div>`;
  }).join('');

  grid.addEventListener('click', e => {
    const card = e.target.closest('.menu-card');
    if (!card) return;
    const size = card.dataset.size;
    if (e.target.closest('[data-add],[data-inc]')) changeQty(size, 1);
    if (e.target.closest('[data-dec]')) changeQty(size, -1);
  });
  syncCards();
}

function changeQty(size, delta) {
  cart[size] = Math.max(0, (cart[size] || 0) + delta);
  if (!cart[size]) delete cart[size];
  store.set('parjuans_cart', cart);
  if (delta > 0) { const f = $('#cartFab'); f.classList.remove('bump'); void f.offsetWidth; f.classList.add('bump'); toast(`🍜 Added bilao ${size} to your order`); }
  syncCards(); renderCart();
}

function syncCards() {
  $$('.menu-card').forEach(c => {
    const q = cart[c.dataset.size] || 0;
    c.classList.toggle('in-cart', q > 0);
    $('[data-q]', c).textContent = q;
  });
}

function renderCart() {
  const entries = Object.entries(cart);
  const count = entries.reduce((s, [, q]) => s + q, 0);
  const total = entries.reduce((s, [size, q]) => s + priceNum(sizeInfo(size).price) * q, 0);
  const badge = $('#cartCount');
  badge.textContent = count; badge.classList.toggle('on', count > 0);
  $('#cartTotal').textContent = peso(total);
  $('#cartSend').disabled = !count;
  $('#cartBody').innerHTML = count ? entries.map(([size, q]) => {
    const it = sizeInfo(size);
    return `<div class="cart-item">
      <img src="images/food.png" alt="" />
      <div class="cart-item-info"><strong>Bilao ${size}</strong><small>${it.pax} · ${it.price}</small></div>
      <div class="qty"><button data-cdec="${esc(size)}" aria-label="Less">−</button><span>${q}</span><button data-cinc="${esc(size)}" aria-label="More">+</button></div>
    </div>`;
  }).join('') : `<div class="cart-empty"><div>🧺</div><p>Your order is empty.<br>Add a bilao from the menu!</p></div>`;
}

function toggleCart(open) {
  $('#cartDrawer').classList.toggle('open', open);
  $('#cartBackdrop').classList.toggle('open', open);
}

function initCart() {
  $('#cartFab').addEventListener('click', () => toggleCart(true));
  $('#cartClose').addEventListener('click', () => toggleCart(false));
  $('#cartBackdrop').addEventListener('click', () => toggleCart(false));
  $('#cartClear').addEventListener('click', () => { cart = {}; store.set('parjuans_cart', cart); syncCards(); renderCart(); });
  $('#cartBody').addEventListener('click', e => {
    const inc = e.target.closest('[data-cinc]'), dec = e.target.closest('[data-cdec]');
    if (inc) changeQty(inc.dataset.cinc, 1);
    if (dec) changeQty(dec.dataset.cdec, -1);
  });
  $('#cartSend').addEventListener('click', () => {
    const lines = Object.entries(cart).map(([s, q]) => `• ${q} × Bilao ${s} (${sizeInfo(s).price})`);
    const total = Object.entries(cart).reduce((s, [z, q]) => s + priceNum(sizeInfo(z).price) * q, 0);
    const text = `Hi Parjuan's! I'd like to order:\n${lines.join('\n')}\nTotal: ${peso(total)}\nPickup/Delivery: `;
    (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(
      () => toast('📋 Order copied — paste it in Messenger!'),
      () => toast('Opening Messenger…')
    ).finally(() => setTimeout(() => window.open(MESSENGER, '_blank'), 700));
  });
  renderCart();
}

// Menu filter chips
function initMenuChips() {
  const wrap = $('#menuChips');
  if (!wrap) return;
  wrap.addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    $$('.chip', wrap).forEach(c => c.classList.toggle('active', c === b));
    $$('.menu-card').forEach(c => c.classList.toggle('hide', b.dataset.f !== 'all' && c.dataset.group !== b.dataset.f));
  });
}

// Party-size finder slider
function initFinder() {
  const range = $('#guestRange'); if (!range) return;
  const update = () => {
    const g = +range.value;
    range.style.setProperty('--pct', ((g - 1) / 29) * 100 + '%');
    $('#guestOut').textContent = g;
    const pick = menuData.find(m => paxRange(m.pax)[1] >= g) || menuData[menuData.length - 1];
    $$('.menu-card').forEach(c => c.classList.toggle('recommended', c.dataset.size === pick.size));
    $('#finderResult').innerHTML = `<span>We suggest <b>Bilao ${pick.size}</b> · ${pick.price}</span>
      <button class="btn btn-primary btn-sm" id="finderAdd">➕ Add it</button>`;
    $('#finderAdd').onclick = () => changeQty(pick.size, 1);
  };
  range.addEventListener('input', update);
  update();
}

function switchTab(name, btn) {
  $$('.menu-tab-btn').forEach(b => b.classList.remove('active'));
  $$('.menu-tab-panel').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  $('#tab-' + name).classList.add('active');
}

// ============================
// GALLERY (filters, likes, lightbox with arrows)
// ============================
let likes = store.get('parjuans_likes', []);
let lbList = [], lbIndex = 0;

function renderGallery() {
  const grid = $('#galleryGrid');
  if (!grid) return;
  const cols = [[], [], []];
  galleryItems.forEach((item, i) => cols[i % 3].push({ ...item, i }));
  grid.innerHTML = cols.map(col => `<div class="pin-col">${col.map(item => `
    <div class="pin-card" data-i="${item.i}" data-tag="${esc(item.tag)}">
      <div class="pin-img-wrap"><img src="${item.src}" alt="${esc(item.caption)}" loading="lazy" />
        <div class="pin-overlay"><div class="pin-view-btn">🔍 View</div></div></div>
      <div class="pin-body">
        <span class="pin-tag">${item.tag}</span>
        <p class="pin-caption">${item.caption}</p>
        <div class="pin-footer">
          <span class="pin-brand"><img src="images/logo.png" class="pin-brand-logo" alt="" /> Parjuan&#39;s</span>
          <span class="pin-heart ${likes.includes(item.i) ? 'liked' : ''}" data-heart role="button" aria-label="Like">♥</span>
        </div>
      </div>
    </div>`).join('')}</div>`).join('');

  grid.addEventListener('click', e => {
    const card = e.target.closest('.pin-card'); if (!card) return;
    const i = +card.dataset.i;
    if (e.target.closest('[data-heart]')) {
      const h = e.target.closest('[data-heart]');
      likes = likes.includes(i) ? likes.filter(x => x !== i) : [...likes, i];
      store.set('parjuans_likes', likes);
      h.classList.remove('liked'); void h.offsetWidth; h.classList.toggle('liked', likes.includes(i));
      return;
    }
    lbList = $$('.pin-card:not(.hide)', grid).map(c => galleryItems[+c.dataset.i]);
    openLightbox(galleryItems[i].src, galleryItems[i].caption, lbList);
  });

  const tags = ['All', ...new Set(galleryItems.map(g => g.tag))];
  const chips = $('#galleryChips');
  chips.innerHTML = tags.map((t, i) => `<button class="chip ${i ? '' : 'active'}" data-t="${esc(t)}">${t}</button>`).join('');
  chips.addEventListener('click', e => {
    const b = e.target.closest('.chip'); if (!b) return;
    $$('.chip', chips).forEach(c => c.classList.toggle('active', c === b));
    $$('.pin-card', grid).forEach(c => c.classList.toggle('hide', b.dataset.t !== 'All' && c.dataset.tag !== b.dataset.t));
  });
}

function openLightbox(src, caption, list) {
  lbList = list || [{ src, caption }];
  lbIndex = Math.max(0, lbList.findIndex(x => x.src === src));
  paintLightbox();
  $('#lightbox').classList.add('open');
}
function paintLightbox() {
  const it = lbList[lbIndex];
  $('#lightboxImg').src = it.src;
  $('#lightboxCaption').textContent = it.caption;
  const multi = lbList.length > 1;
  $('#lbPrev').classList.toggle('hidden', !multi);
  $('#lbNext').classList.toggle('hidden', !multi);
}
function stepLightbox(d) { lbIndex = (lbIndex + d + lbList.length) % lbList.length; paintLightbox(); }
function closeLightbox() { $('#lightbox').classList.remove('open'); }
function initLightbox() {
  $('#lightboxClose').addEventListener('click', closeLightbox);
  $('#lbPrev').addEventListener('click', e => { e.stopPropagation(); stepLightbox(-1); });
  $('#lbNext').addEventListener('click', e => { e.stopPropagation(); stepLightbox(1); });
  $('#lightbox').addEventListener('click', function (e) { if (e.target === this || e.target.classList.contains('lightbox-content')) closeLightbox(); });
  let sx = 0;
  $('#lightbox').addEventListener('touchstart', e => { sx = e.touches[0].clientX; }, { passive: true });
  $('#lightbox').addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 50 && lbList.length > 1) stepLightbox(dx < 0 ? 1 : -1); });
}

// ============================
// BRANCHES (click to copy address)
// ============================
function renderBranches() {
  const grid = $('#branchesGrid');
  if (!grid) return;
  grid.innerHTML = branchData.map((b, i) => `
    <div class="branch-card">
      <div class="branch-icon">📍</div>
      <div class="branch-name">${b.name}</div>
      <div class="branch-address">${b.address}</div>
      <button class="branch-copy" data-copy="${i}">📋 Copy address</button>
      <div class="branch-phones">${b.phones.map(p => `<a href="tel:${p.replace(/-/g, '')}" class="branch-phone-link">📞 ${p}</a>`).join('')}</div>
      <a href="${b.map}" target="_blank" rel="noopener" class="branch-map-btn">🗺️ View on Maps</a>
    </div>`).join('');
  grid.addEventListener('click', e => {
    const b = e.target.closest('[data-copy]'); if (!b) return;
    const addr = branchData[+b.dataset.copy].address;
    (navigator.clipboard ? navigator.clipboard.writeText(addr) : Promise.reject()).then(() => toast('📋 Address copied!'), () => toast(addr));
  });
}

// ============================
// TESTIMONIALS (autoplay, hover-pause, drag/swipe, resize-safe)
// ============================
function setupTestimonials(trackId, dotsId, prevId, nextId) {
  const track = $('#' + trackId), dots = $('#' + dotsId);
  if (!track || !dots) return;
  const bubbles = [[18,12,0,3.2],[10,30,.6,2.8],[14,52,1.1,3.6],[8,70,.3,2.5],[16,85,1.5,3],[11,44,.9,4]]
    .map(([s, l, d, u]) => `<span class="t-bubble" style="width:${s}px;height:${s}px;left:${l}%;animation-delay:${d}s;animation-duration:${u}s"></span>`).join('');
  track.innerHTML = testimonialData.map((t, i) => `
    <div class="testimonial-card${i === 2 ? ' has-bubbles' : ''}">${i === 2 ? bubbles : ''}
      <div class="testimonial-quote">"</div><p class="testimonial-text">${t.text}</p>
      <div class="testimonial-author"><div class="testimonial-avatar">${t.emoji}</div>
        <div><div class="testimonial-name">${t.name}</div><div class="testimonial-loc">📍 ${t.loc}</div><div class="testimonial-stars">★★★★★</div></div></div>
    </div>`).join('');

  const slider = track.parentElement, cards = $$('.testimonial-card', track);
  let idx = 0, max = 0, timer;
  const vis = () => (window.innerWidth >= 1024 ? 3 : window.innerWidth >= 640 ? 2 : 1);
  const build = () => {
    max = Math.max(0, cards.length - vis());
    dots.innerHTML = Array.from({ length: max + 1 }, (_, i) => `<button class="slider-dot" aria-label="Slide ${i + 1}"></button>`).join('');
    $$('.slider-dot', dots).forEach((d, i) => d.addEventListener('click', () => go(i)));
    go(Math.min(idx, max));
  };
  function go(i) {
    idx = Math.max(0, Math.min(i, max));
    track.style.transform = `translateX(-${idx * (cards[0].offsetWidth + 24)}px)`;
    $$('.slider-dot', dots).forEach((d, j) => d.classList.toggle('active', j === idx));
  }
  const play = () => { clearInterval(timer); timer = setInterval(() => go(idx >= max ? 0 : idx + 1), 4500); };
  $('#' + prevId).addEventListener('click', () => { go(idx - 1); play(); });
  $('#' + nextId).addEventListener('click', () => { go(idx >= max ? 0 : idx + 1); play(); });
  slider.addEventListener('mouseenter', () => clearInterval(timer));
  slider.addEventListener('mouseleave', play);

  let startX = 0, down = false, dx = 0;
  slider.addEventListener('pointerdown', e => { down = true; startX = e.clientX; dx = 0; slider.classList.add('dragging'); });
  window.addEventListener('pointermove', e => {
    if (!down) return;
    dx = e.clientX - startX;
    track.style.transform = `translateX(${-idx * (cards[0].offsetWidth + 24) + dx}px)`;
  });
  window.addEventListener('pointerup', () => {
    if (!down) return; down = false; slider.classList.remove('dragging');
    if (Math.abs(dx) > 50) go(dx < 0 ? idx + 1 : idx - 1); else go(idx);
    play();
  });
  let rt; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(build, 200); });
  build(); play();
}

// ============================
// GLOBAL UI: navbar, progress, back-to-top, hamburger, reveal
// ============================
function initScrollUI() {
  const nav = $('#navbar'), bar = $('#scrollProgress'), top = $('#toTop');
  const on = () => {
    const y = window.scrollY, h = document.documentElement.scrollHeight - innerHeight;
    nav.classList.toggle('scrolled', y > 60);
    bar.style.width = (h > 0 ? (y / h) * 100 : 0) + '%';
    top.classList.toggle('show', y > 600);
  };
  window.addEventListener('scroll', on, { passive: true });
  top.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  on();
}

function initHamburger() {
  const hb = $('#hamburger'), mm = $('#mobileMenu');
  hb.addEventListener('click', () => {
    const open = mm.classList.toggle('open');
    hb.classList.toggle('open', open);
    hb.setAttribute('aria-expanded', open);
  });
  document.addEventListener('click', e => { if (!hb.contains(e.target) && !mm.contains(e.target)) closeMobile(); });
}
window.closeMobile = function () {
  $('#mobileMenu').classList.remove('open');
  $('#hamburger').classList.remove('open');
  $('#hamburger').setAttribute('aria-expanded', 'false');
};

let revealObs;
function initReveal() {
  revealObs = revealObs || new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); revealObs.unobserve(e.target); } });
  }, { threshold: 0.1 });
  $$('.page.active .reveal:not(.visible)').forEach(el => revealObs.observe(el));
}

// Animated hero numbers
function runCountUp() {
  $$('[data-count]').forEach(el => {
    const end = +el.dataset.count, pre = el.dataset.prefix || '', suf = el.dataset.suffix || '';
    const t0 = performance.now(), dur = 1400;
    const tick = t => {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = pre + Math.round(end * e) + suf;
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
}

// Hero plate follows the mouse (3D tilt)
function initTilt() {
  const plate = $('.hero-plate'), hero = $('.hero');
  if (!plate || matchMedia('(hover: none)').matches) return;
  hero.addEventListener('mousemove', e => {
    const r = hero.getBoundingClientRect();
    const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
    plate.style.transform = `perspective(700px) rotateY(${x * 16}deg) rotateX(${-y * 16}deg) scale(1.03)`;
  });
  hero.addEventListener('mouseleave', () => { plate.style.transform = ''; });
}

// Click ripple on buttons
function initRipple() {
  document.addEventListener('click', e => {
    const b = e.target.closest('.btn, .menu-card-btn'); if (!b) return;
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height);
    const s = document.createElement('span');
    s.className = 'ripple';
    s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
    b.appendChild(s); setTimeout(() => s.remove(), 600);
  });
}

// Keyboard: Esc closes things, arrows browse lightbox
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeLightbox(); toggleCart(false); closeMobile(); }
  if ($('#lightbox').classList.contains('open') && lbList.length > 1) {
    if (e.key === 'ArrowRight') stepLightbox(1);
    if (e.key === 'ArrowLeft') stepLightbox(-1);
  }
});

// ============================
// CONTACT FORM
// ============================
function initContactForm() {
  const form = $('#contactForm'); if (!form) return;
  const msg = $('#message'), now = $('#charNow'), cnt = $('.char-count');
  msg.addEventListener('input', () => {
    now.textContent = msg.value.length;
    cnt.classList.toggle('warn', msg.value.length > 520);
  });
  form.addEventListener('submit', e => {
    if (!form.checkValidity()) {
      e.preventDefault(); e.stopPropagation();
      form.classList.add('was-validated');
      const bad = $(':invalid', form); if (bad) bad.focus();
      toast('⚠️ Please complete the highlighted fields');
      return;
    }
    $('#sendBtn').classList.add('loading');
  });
}

function showFormStatus() {
  const status = new URLSearchParams(location.search).get('status');
  if (!status) return false;
  const messages = {
    success: ['success', 'Thank you! Your message was sent and saved. 🎉'],
    invalid: ['warning', 'Please fill in all required fields with a valid email.'],
    error:   ['danger',  'Sorry, something went wrong on our end. Please try again later.'],
  };
  const info = messages[status]; if (!info) return false;
  $('#formAlert').innerHTML = `<div class="alert alert-${info[0]} alert-dismissible fade show" role="alert">${info[1]}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>`;
  history.replaceState(null, '', location.pathname + '#contact');
  showPage('contact', { fromHash: true, instant: true });
  return true;
}

// ============================
// INIT
// ============================
document.addEventListener('DOMContentLoaded', () => {
  // Portfolio demo: each step runs on its own so a section missing from the static page can't stop the rest.
  const run = fn => { try { fn(); } catch (e) { console.warn('skipped:', e.message); } };
  [renderMarquee, renderMenu, renderToppings, renderGallery, renderBranches,
   () => setupTestimonials('homeTestimonialsTrack', 'homeSliderDots', 'homeSliderPrev', 'homeSliderNext'),
   initScrollUI, initHamburger, initLightbox, initCart, initMenuChips, initFinder,
   initTilt, initRipple, initContactForm].forEach(run);
  run(() => { if (!showFormStatus()) showPage(location.hash.slice(1) || 'home', { fromHash: true, instant: true }); });
  run(initReveal);
});
