(function () {
  'use strict';

  var LS_KEY = 'hansi_videos_v1', LS_PASS = 'hansi_owner_pass_v1', SS_OWNER = 'hansi_owner_on';
  var DB_NAME = 'hansi-videos', STORE = 'files';
  var $ = function (id) { return document.getElementById(id); };
  var activeCat = 'All', manageOpen = false, fileUrls = [];
  var owner = sessionStorage.getItem(SS_OWNER) === '1';

  /* ================= helpers ================= */
  function ytIdFrom(url) {
    try {
      var u = new URL(url.trim()), h = u.hostname.replace(/^www\./, '');
      if (h === 'youtu.be') return u.pathname.slice(1).split('/')[0];
      if (h.indexOf('youtube.com') !== -1) {
        if (u.searchParams.get('v')) return u.searchParams.get('v');
        var m = u.pathname.match(/^\/(shorts|embed|live)\/([\w-]{6,})/);
        if (m) return m[2];
      }
    } catch (e) {}
    return null;
  }
  function el(tag, cls, text) { var n = document.createElement(tag); if (cls) n.className = cls; if (text != null) n.textContent = text; return n; }
  function setMsg(id, text, kind) { var m = $(id); m.textContent = text || ''; m.className = 'msg' + (kind ? ' ' + kind : ''); }

  /* ================= owner mode (hides the upload area from visitors) ================= */
  function sha(str) {
    if (window.crypto && crypto.subtle) {
      return crypto.subtle.digest('SHA-256', new TextEncoder().encode('hansi:' + str)).then(function (b) {
        return Array.prototype.map.call(new Uint8Array(b), function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
      });
    }
    var h = 5381; for (var i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return Promise.resolve('x' + h);
  }
  function setOwner(on) {
    owner = on;
    if (on) sessionStorage.setItem(SS_OWNER, '1'); else sessionStorage.removeItem(SS_OWNER);
    $('owner-bar').hidden = !on;
    if (!on) { manageOpen = false; $('manage').classList.remove('open'); $('manage-toggle').innerHTML = ico('plus') + ' Add / upload a video'; }
    render();
  }
  function unlockFlow() {
    var saved = localStorage.getItem(LS_PASS);
    if (!saved) {
      var np = prompt('Owner mode setup: create a passcode (only for this browser).');
      if (!np) return;
      sha(np).then(function (hh) { localStorage.setItem(LS_PASS, hh); setOwner(true); });
    } else {
      var pw = prompt('Owner passcode:');
      if (!pw) return;
      sha(pw).then(function (hh) { if (hh === saved) setOwner(true); else alert('Wrong passcode.'); });
    }
  }
  function checkHash() {
    if (location.hash === '#owner') {
      history.replaceState(null, '', location.pathname + location.search);
      if (!owner) unlockFlow();
    }
  }
  window.addEventListener('hashchange', checkHash);
  $('owner-lock').addEventListener('click', function () { setOwner(false); });
  $('owner-reset').addEventListener('click', function (e) {
    e.preventDefault();
    var np = prompt('New owner passcode:'); if (!np) return;
    sha(np).then(function (hh) { localStorage.setItem(LS_PASS, hh); alert('Passcode updated.'); });
  });

  /* ================= storage (private videos) ================= */
  function loadLocal() { try { return JSON.parse(localStorage.getItem(LS_KEY) || '[]'); } catch (e) { return []; } }
  function saveLocal(list) { try { localStorage.setItem(LS_KEY, JSON.stringify(list)); return true; } catch (e) { return false; } }
  function openDB() {
    return new Promise(function (res, rej) {
      if (!window.indexedDB) return rej(new Error('IndexedDB unavailable'));
      var r = indexedDB.open(DB_NAME, 1);
      r.onupgradeneeded = function () { r.result.createObjectStore(STORE, { keyPath: 'id' }); };
      r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); };
    });
  }
  function dbAll() {
    return openDB().then(function (db) {
      return new Promise(function (res, rej) {
        var q = db.transaction(STORE).objectStore(STORE).getAll();
        q.onsuccess = function () { res(q.result || []); }; q.onerror = function () { rej(q.error); };
      });
    }).catch(function () { return []; });
  }
  function dbPut(rec) {
    return openDB().then(function (db) {
      return new Promise(function (res, rej) {
        var tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).put(rec);
        tx.oncomplete = res; tx.onerror = function () { rej(tx.error); };
      });
    });
  }
  function dbDelete(id) {
    return openDB().then(function (db) {
      return new Promise(function (res) { var tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).delete(id); tx.oncomplete = res; tx.onerror = res; });
    }).catch(function () {});
  }

  /* ================= video grid ================= */
  function allVideos() {
    var pub = (window.PORTFOLIO_VIDEOS || []).map(function (v) { return Object.assign({ mine: false }, v); });
    if (!owner) return Promise.resolve(pub);              // visitors: public videos only
    var loc = loadLocal().map(function (v) { return Object.assign({ mine: true }, v); });
    return dbAll().then(function (files) {
      fileUrls.forEach(function (u) { URL.revokeObjectURL(u); }); fileUrls = [];
      var fl = files.map(function (f) {
        var url = URL.createObjectURL(f.blob); fileUrls.push(url);
        return { id: f.id, title: f.title, category: f.category, desc: f.desc, type: 'file', src: url, mine: true };
      });
      return pub.concat(loc, fl);
    });
  }
  function mediaFor(v) {
    var box = el('div', 'vid-media' + (v.orient === 'vertical' ? ' tall' : ''));
    if (v.type === 'youtube' && v.ytId) {
      var img = el('img'); img.loading = 'lazy'; img.alt = v.title;
      img.src = 'https://i.ytimg.com/vi/' + encodeURIComponent(v.ytId) + '/hqdefault.jpg';
      var btn = el('button', 'vid-play'); btn.type = 'button'; btn.setAttribute('aria-label', 'Play ' + v.title);
      var pl = el('span'); pl.innerHTML = ico('play'); btn.appendChild(pl);
      btn.addEventListener('click', function () {
        if (location.protocol !== 'http:' && location.protocol !== 'https:') { window.open('https://www.youtube.com/watch?v=' + encodeURIComponent(v.ytId), '_blank', 'noopener'); return; }
        box.textContent = '';
        var f = document.createElement('iframe');
        f.src = 'https://www.youtube.com/embed/' + encodeURIComponent(v.ytId) + '?autoplay=1&rel=0';
        f.referrerPolicy = 'strict-origin-when-cross-origin'; f.title = v.title;
        f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen'; f.allowFullscreen = true;
        box.appendChild(f);
      });
      box.appendChild(img); box.appendChild(btn);
    } else if (v.type === 'file' && v.src) {
      var vid = document.createElement('video'); vid.controls = true; vid.preload = v.poster ? 'none' : 'metadata'; vid.playsInline = true; vid.setAttribute('playsinline', ''); if (v.poster) vid.poster = v.poster; vid.src = v.src;
      vid.addEventListener('play', function () { document.querySelectorAll('.vid-media video').forEach(function (o) { if (o !== vid) o.pause(); }); });
      box.appendChild(vid);
    }
    return box;
  }
  function render() {
    allVideos().then(function (list) {
      var cats = ['All'];
      list.forEach(function (v) { if (v.category && cats.indexOf(v.category) < 0) cats.push(v.category); });
      if (cats.indexOf(activeCat) < 0) activeCat = 'All';
      var chips = $('chips'); chips.textContent = '';
      if (cats.length > 2) cats.forEach(function (c) {
        var b = el('button', 'chip' + (c === activeCat ? ' on' : ''), c); b.type = 'button';
        b.addEventListener('click', function () { activeCat = c; render(); }); chips.appendChild(b);
      });
      var grid = $('vid-grid'); grid.textContent = '';
      var shown = list.filter(function (v) { return activeCat === 'All' || v.category === activeCat; });
      if (!shown.length) {
        var empty = el('div', 'vid-empty');
        empty.appendChild(document.createTextNode('More edits are on the way — in the meantime, watch my work on '));
        var a = el('a', null, 'YouTube'); a.href = 'https://www.youtube.com/@dx_nice'; a.target = '_blank'; a.rel = 'noopener'; a.style.color = 'var(--rose-deep)';
        empty.appendChild(a); empty.appendChild(document.createTextNode('.')); grid.appendChild(empty); return;
      }
      shown.forEach(function (v) {
        var card = el('div', 'vid-card'); card.appendChild(mediaFor(v));
        var body = el('div', 'vid-body'), cat = el('div', 'vid-cat', v.category || 'Video');
        if (v.mine) cat.appendChild(el('span', 'mine-tag', 'private · only you'));
        body.appendChild(cat); body.appendChild(el('h3', null, v.title + (v.duration ? '  ·  ' + v.duration : '')));
        if (v.desc) body.appendChild(el('p', null, v.desc));
        if (v.mine && manageOpen) {
          var del = el('button', 'vid-del', 'Remove'); del.type = 'button';
          del.addEventListener('click', function () { removeVideo(v); }); body.appendChild(del);
        }
        card.appendChild(body); grid.appendChild(card);
      });
    });
  }
  function removeVideo(v) {
    if (!confirm('Remove “' + v.title + '”?')) return;
    if (v.type === 'file') dbDelete(v.id).then(render);
    else { saveLocal(loadLocal().filter(function (x) { return x.id !== v.id; })); render(); }
  }

  /* ================= owner: add / upload ================= */
  $('manage-toggle').addEventListener('click', function () {
    if (!owner) return;
    manageOpen = !manageOpen; $('manage').classList.toggle('open', manageOpen);
    this.innerHTML = manageOpen ? ico('x') + ' Close' : ico('plus') + ' Add / upload a video'; render();
  });
  $('v-type').addEventListener('change', function () {
    var f = this.value === 'file'; $('f-file').style.display = f ? '' : 'none'; $('f-yt').style.display = f ? 'none' : '';
  });
  $('v-save').addEventListener('click', function () {
    if (!owner) return;
    var title = $('v-title').value.trim(), cat = $('v-cat').value, desc = $('v-desc').value.trim(), type = $('v-type').value, id = 'v' + Date.now();
    if (!title) return setMsg('v-msg', 'Please add a title.', 'err');
    if (type === 'youtube') {
      var yt = ytIdFrom($('v-url').value);
      if (!yt) return setMsg('v-msg', 'That doesn’t look like a YouTube link.', 'err');
      var list = loadLocal(); list.push({ id: id, title: title, category: cat, desc: desc, type: 'youtube', ytId: yt });
      if (!saveLocal(list)) return setMsg('v-msg', 'Could not save in this browser.', 'err');
      done();
    } else {
      var file = $('v-file').files[0];
      if (!file) return setMsg('v-msg', 'Choose a video file first.', 'err');
      if (file.type && file.type.indexOf('video/') !== 0) return setMsg('v-msg', 'That file is not a video.', 'err');
      setMsg('v-msg', 'Saving…');
      dbPut({ id: id, title: title, category: cat, desc: desc, blob: file, name: file.name, created: Date.now() }).then(done)
        .catch(function () { setMsg('v-msg', 'Could not save this file (storage may be full). Try a smaller file or a YouTube link.', 'err'); });
    }
    function done() {
      $('v-title').value = ''; $('v-url').value = ''; $('v-desc').value = ''; $('v-file').value = '';
      setMsg('v-msg', 'Saved privately. Only you can see it. Use “Copy code” to publish a YouTube video for everyone.', 'ok'); render();
    }
  });
  $('v-export').addEventListener('click', function () {
    if (!owner) return;
    var yt = loadLocal().filter(function (v) { return v.type === 'youtube'; }), box = $('export-box'), ta = $('export-text');
    if (!yt.length) { box.style.display = 'none'; return setMsg('v-msg', 'Add a YouTube video first, then copy its code.', 'err'); }
    ta.value = yt.map(function (v) { return '  ' + JSON.stringify({ title: v.title, category: v.category, desc: v.desc, type: 'youtube', ytId: v.ytId }) + ','; }).join('\n');
    box.style.display = 'block'; ta.select();
    var copied = false; try { copied = document.execCommand('copy'); } catch (e) {}
    setMsg('v-msg', copied ? 'Copied! Paste it inside the list in js/videos.js.' : 'Select and copy the code below, then paste it inside the list in js/videos.js.', 'ok');
  });

  /* ================= dynamic order form ================= */
  var TYPES = {
    youtube: { label: 'YouTube video',                       unit: 'min', min: 1,  max: 60,  step: 1, def: 8,  orient: '16:9', block: 60 },
    short:   { label: 'Short-form (Reels / TikTok / Shorts)', unit: 'sec', min: 15, max: 180, step: 5, def: 45, orient: '9:16', block: 15 },
    gaming:  { label: 'Gaming video / montage',              unit: 'min', min: 1,  max: 30,  step: 1, def: 5,  orient: '16:9', block: 60 },
    event:   { label: 'School / event video',                unit: 'min', min: 1,  max: 20,  step: 1, def: 4,  orient: '16:9', block: 60 },
    other:   { label: 'Other',                               unit: 'min', min: 1,  max: 60,  step: 1, def: 3,  orient: '16:9', block: 60 }
  };
  var EXTRAS = {
    captions: ['message', 'Captions / subtitles'], music: ['headphones', 'Music & sound effects'], color: ['palette', 'Color grading'],
    intro: ['sparkle', 'Intro / outro'], thumb: ['image', 'Thumbnail'], motion: ['layers', 'Motion graphics']
  };
  var tSel = $('h-type'), dur = $('h-dur'), exWrap = $('h-extras');
  Object.keys(TYPES).forEach(function (k) { var o = el('option', null, TYPES[k].label); o.value = k; tSel.appendChild(o); });
  Object.keys(EXTRAS).forEach(function (k) {
    var l = el('label', 'extra'), i = document.createElement('input'); i.type = 'checkbox'; i.value = k;
    i.addEventListener('change', summary); l.appendChild(i); var sp = el('span'); sp.innerHTML = ico(EXTRAS[k][0]) + ' ' + EXTRAS[k][1]; l.appendChild(sp); exWrap.appendChild(l);
  });
  function fmt(v, unit) { return unit === 'sec' ? (v >= 60 ? Math.floor(v / 60) + ' min ' + (v % 60 ? v % 60 + ' sec' : '') : v + ' sec') : v + ' min'; }
  function applyType() {
    var t = TYPES[tSel.value];
    dur.min = t.min; dur.max = t.max; dur.step = t.step; dur.value = t.def;
    $('h-dur-min').textContent = fmt(t.min, t.unit); $('h-dur-max').textContent = fmt(t.max, t.unit);
    $('h-orient').value = t.orient; summary();
  }
  function selectedExtras() { return Array.prototype.filter.call(exWrap.querySelectorAll('input'), function (i) { return i.checked; }).map(function (i) { return i.value; }); }
  function isRush() {
    var d = $('h-date').value; if (!d) return false;
    var days = (new Date(d + 'T23:59:59') - new Date()) / 86400000; return days >= 0 && days < 3;
  }
  function summary() {
    var t = TYPES[tSel.value], v = +dur.value, secs = t.unit === 'min' ? v * 60 : v, ex = selectedExtras(), rush = isRush();
    dur.style.setProperty('--fill', ((v - t.min) / (t.max - t.min) * 100) + '%');
    $('h-dur-out').textContent = fmt(v, t.unit);
    var pts = secs <= 60 ? 1 : secs <= 300 ? 2 : secs <= 900 ? 3 : 4;
    pts += ex.length * 0.75 + (tSel.value === 'gaming' || tSel.value === 'event' ? 0.5 : 0);
    var lvl = pts <= 2 ? [1, 'Quick edit'] : pts <= 4 ? [2, 'Standard edit'] : pts <= 6 ? [3, 'Detailed edit'] : [4, 'Big project'];

    var box = $('h-summary'); box.textContent = '';
    box.appendChild(el('h4', null, 'Your order summary'));
    function line(k, val, rushTag) {
      var d = el('div', 'line'); d.appendChild(el('span', null, k)); var s = el('strong', null, val);
      if (rushTag) s.appendChild(el('span', 'rush', 'RUSH')); d.appendChild(s); box.appendChild(d);
    }
    line('Type', t.label); line('Length', fmt(v, t.unit)); line('Format', $('h-orient').value);
    line('Extras', ex.length ? ex.map(function (k) { return EXTRAS[k][1]; }).join(', ') : 'None');
    line('Deadline', $('h-date').value || 'Flexible', rush);
    box.appendChild(el('span', 'level l' + lvl[0], lvl[1]));

    var R = window.EDIT_RATES, total = 0;
    if (R && R.perUnit) {
      total = (R.perUnit[tSel.value] || 0) * Math.ceil(secs / t.block);
      ex.forEach(function (k) { total += (R.extras && R.extras[k]) || 0; });
      if (rush && R.rushPercent) total = total * (1 + R.rushPercent / 100);
    }
    var pr = el('div', 'price', total > 0 ? 'Estimate: ' + (R.currency || '') + Math.round(total).toLocaleString() : 'Price: I’ll send you a quote by email');
    box.appendChild(pr);
    return { t: t, v: v, ex: ex, rush: rush, lvl: lvl[1], total: total, R: R };
  }
  tSel.addEventListener('change', applyType);
  dur.addEventListener('input', summary);
  $('h-orient').addEventListener('change', summary);
  $('h-date').addEventListener('change', summary);
  $('h-date').min = new Date().toISOString().slice(0, 10);

  $('hire-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var name = $('h-name').value.trim(), email = $('h-email').value.trim(), msg = $('h-msg').value.trim();
    if (!name || !msg) return setMsg('h-msg-status', 'Please add your name and a short description.', 'err');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return setMsg('h-msg-status', 'Please enter a valid email.', 'err');
    var s = summary();
    var body = 'Hi Hansi,\n\nName: ' + name + '\nEmail: ' + email +
      '\n\n— ORDER —\nType: ' + s.t.label + '\nLength: ' + fmt(s.v, s.t.unit) + '\nFormat: ' + $('h-orient').value +
      '\nExtras: ' + (s.ex.length ? s.ex.map(function (k) { return EXTRAS[k][1]; }).join(', ') : 'None') +
      '\nDeadline: ' + ($('h-date').value || 'Flexible') + (s.rush ? ' (RUSH)' : '') +
      '\nComplexity: ' + s.lvl + (s.total > 0 ? '\nEstimate: ' + (s.R.currency || '') + Math.round(s.total) : '') +
      '\n\nProject details:\n' + msg + '\n';
    window.location.href = 'mailto:edibyhansi@gmail.com?subject=' +
      encodeURIComponent('Video editing order — ' + s.t.label + ' (' + fmt(s.v, s.t.unit) + ')') + '&body=' + encodeURIComponent(body);
    setMsg('h-msg-status', 'Opening your email app… if nothing opens, email edibyhansi@gmail.com directly.', 'ok');
  });

  /* ================= init ================= */
  $('owner-bar').hidden = !owner;
  applyType();
  render();
  checkHash();
})();
