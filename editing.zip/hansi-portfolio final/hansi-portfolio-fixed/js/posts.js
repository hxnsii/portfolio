/**
 * BLOG POSTS DATA
 * To add a new post: copy one object, paste it at the TOP of the array,
 * give it a unique id, update the date, title, excerpt, content, and tags.
 * content supports basic HTML (<p>, <strong>, <em>, <ul>, <li>, <a>, <code>).
 */
window.BLOG_POSTS = [
  {
    id: "dean-list-2025",
    date: "2025-12-10",
    icon: "flower",
    color: "rose",
    title: "Made the Dean's List — here's what actually helped",
    excerpt: "1st year, 1st semester at FEU IT done. I made the Dean's List and I want to share the study habits that genuinely made the difference.",
    tags: ["student life", "study tips", "FEU"],
    content: `
      <p>I'll be honest — my first semester at FEU was harder than I expected. New environment, harder subjects, and the pressure of actually living up to the scholarship. But it worked out. <strong>Dean's List.</strong> Here's what helped:</p>
      <ul>
        <li><strong>Active recall over re-reading.</strong> I stopped highlighting notes and started quizzing myself. Flashcards for every concept, every syntax rule.</li>
        <li><strong>One subject per deep-work block.</strong> Context switching is the enemy. I'd close everything else and spend 90 minutes on one thing.</li>
        <li><strong>Teaching it out loud.</strong> If I couldn't explain a concept to my bedroom wall, I didn't understand it yet.</li>
        <li><strong>Sleep is non-negotiable.</strong> All-nighters feel productive. They are not.</li>
      </ul>
      <p>Next semester I'm adding a consistent exercise habit on top of this. We'll see how it goes.</p>
    `
  },
  {
    id: "pygame-snake-devlog",
    date: "2025-10-22",
    icon: "gamepad",
    color: "gold",
    title: "Building Snake in Pygame — a dev log",
    excerpt: "I built a full Snake game in Python with Pygame and posted it on YouTube. Here's what I learned building my first real game from scratch.",
    tags: ["python", "pygame", "game dev", "devlog"],
    content: `
      <p>My first real project with Pygame was a Snake clone. Sounds simple — it really isn't once you start thinking about collision detection, score persistence, and making it actually <em>feel</em> good to play.</p>
      <p><strong>The grid system</strong> was the first thing that clicked for me. Everything in Snake lives on a grid. The snake is a list of (x, y) tuples. Movement is just prepending a new head and popping the tail. Food is a random grid cell that isn't occupied by the snake.</p>
      <p>The hardest part was the <strong>game loop timing</strong>. pygame's <code>clock.tick()</code> controls how fast the snake moves — too fast and it's unplayable, too slow and it's boring. I ended up making speed increase slightly every time the snake eats, which makes the late game genuinely tense.</p>
      <ul>
        <li>Total lines of code: ~280</li>
        <li>Time to first working prototype: 3 hours</li>
        <li>Time to a version I was happy with: about a week of evenings</li>
      </ul>
      <p>You can watch the full video on my <a href="https://youtu.be/5ULfsFqyzwY" target="_blank">YouTube channel</a>. Next up: something with a proper level system.</p>
    `
  },
  {
    id: "why-it-feu",
    date: "2025-08-05",
    icon: "book",
    color: "lavender",
    title: "Why I chose BS Information Technology at FEU",
    excerpt: "A lot of people asked me why IT and not Computer Science. Here's my honest answer, and what I hope to build during my four years here.",
    tags: ["feu", "student life", "goals"],
    content: `
      <p>When I was finishing Grade 12, I had to choose between BS Computer Science and BS Information Technology. Most people assumed I'd pick CS — "it's more technical," they said.</p>
      <p>Here's why I chose IT: I don't just want to write code. I want to <strong>build things that work for real people</strong> — systems, applications, software that solves actual problems. IT's curriculum covers the full stack of that: networking, databases, systems analysis, web development, AND the programming fundamentals.</p>
      <p>FEU specifically felt right because of the project-based learning approach and the strong alumni network in Philippine tech companies. Also, the campus is great.</p>
      <p>What I hope to build by graduation:</p>
      <ul>
        <li>At least one full-stack web application deployed and used by real users</li>
        <li>A portfolio of games and creative coding projects</li>
        <li>An internship at a company whose work I actually believe in</li>
        <li>Good friendships with people smarter than me</li>
      </ul>
      <p>Year 2 is going well so far. Check back here for updates.</p>
    `
  },
  {
    id: "learning-web-dev",
    date: "2025-06-14",
    icon: "globe",
    color: "sage",
    title: "How I actually learned HTML & CSS (no bootcamp)",
    excerpt: "I didn't take a paid course. I built things, broke things, and read a lot of MDN. Here's my self-taught frontend journey from scratch.",
    tags: ["html", "css", "web dev", "self-taught"],
    content: `
      <p>I started learning HTML the summer before college. No bootcamp, no paid Udemy course — just MDN, YouTube, and a stubborn refusal to use templates.</p>
      <p><strong>The loop that actually worked for me:</strong></p>
      <ul>
        <li>Pick something I wanted to exist (a personal page, a game UI, a to-do list)</li>
        <li>Try to build it with what I knew</li>
        <li>Hit a wall</li>
        <li>Search specifically for that wall — not "how to make a website" but "how to center a div vertically in CSS"</li>
        <li>Read the MDN article, not just the Stack Overflow answer</li>
        <li>Repeat</li>
      </ul>
      <p>The biggest unlock was understanding <strong>the box model</strong> properly. Once I really got that everything is a box with margin, border, padding, and content — layout stopped being magic and became predictable.</p>
      <p>Flexbox and Grid came later and honestly changed everything. If you're learning CSS right now: skip floats, learn Flexbox first, then Grid. You'll thank yourself.</p>
      <p>This portfolio is the current result of that process. It'll keep getting better.</p>
    `
  }
];
