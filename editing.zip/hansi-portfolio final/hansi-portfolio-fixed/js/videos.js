/**
 * videos.js — the PUBLIC list of videos everyone sees on the Editing page.
 *
 * Add an entry for each video you want visitors to see.
 *
 * YouTube video:
 *   { title: "My edit", category: "YouTube", desc: "What I edited", type: "youtube", ytId: "VIDEO_ID" }
 *   (VIDEO_ID is the part after v= in the link, or after youtu.be/)
 *
 * Video file (put the file inside assets/videos/; add a poster image and orient: "vertical" for 9:16 videos):
 *   { title: "My edit", category: "Short-form", desc: "What I edited", type: "file", src: "../assets/videos/my-edit.mp4" }
 *
 * Tip: on the Editing page, click "+ Add / upload a video", add your YouTube
 * links, then press "Copy code for js/videos.js" and paste the result below.
 */
window.PORTFOLIO_VIDEOS = [
  { title: "AI & viral video — podcast clip", category: "Short-form", desc: "Podcast highlight with animated captions, a clean title card and punchy pacing for Reels, TikTok and Shorts.", type: "file", src: "../assets/videos/ai-edit.mp4", poster: "../assets/videos/ai-edit.jpg", orient: "vertical", duration: "0:30" },
  { title: "Decision regret — podcast clip", category: "Short-form", desc: "Word-by-word glowing captions and tight cuts that keep the viewer watching.", type: "file", src: "../assets/videos/decision-regret.mp4", poster: "../assets/videos/decision-regret.jpg", orient: "vertical", duration: "0:31" },
  { title: "Love & quality — podcast clip", category: "Short-form", desc: "Dynamic caption highlights and rhythm-based editing on a talking-head clip.", type: "file", src: "../assets/videos/love-quality.mp4", poster: "../assets/videos/love-quality.jpg", orient: "vertical", duration: "0:31" },
  { title: "Survival mechanism — podcast clip", category: "Short-form", desc: "Close-up framing with animated captions designed for vertical, sound-on viewing.", type: "file", src: "../assets/videos/survival-mechanism.mp4", poster: "../assets/videos/survival-mechanism.jpg", orient: "vertical", duration: "0:31" },
];

/**
 * OPTIONAL — your editing rates. Leave these at 0 and visitors will see
 * "I'll send you a quote by email". Fill in numbers and the order form on the
 * Editing page will show a live price estimate.
 *
 * perUnit  = price per minute (YouTube, gaming, event, other) or per 15 seconds (short-form)
 * extras   = flat price for each add-on
 * rushPercent = extra % when the deadline is within 3 days
 */
window.EDIT_RATES = {
  currency: '₱',
  perUnit: { youtube: 0, short: 0, gaming: 0, event: 0, other: 0 },
  extras: { captions: 0, music: 0, color: 0, intro: 0, thumb: 0, motion: 0 },
  rushPercent: 0
};
