document.addEventListener('DOMContentLoaded', () => {

  // ── Active nav link based on current page ──
  const currentPage = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a, .nav-drawer a').forEach(a => {
    const href = a.getAttribute('href');
    if (!href) return;
    const page = href.split('/').pop();
    if (page === currentPage || (currentPage === '' && page === 'index.html')) {
      a.classList.add('active');
    }
  });

  // ── Hamburger menu ──
  const toggle = document.getElementById('nav-toggle');
  const drawer = document.getElementById('nav-drawer');
  const nav    = document.getElementById('main-nav');

  if (toggle && drawer) {
    toggle.addEventListener('click', () => {
      const isOpen = drawer.classList.contains('open');
      drawer.classList.toggle('open');
      toggle.classList.toggle('open');
      toggle.setAttribute('aria-expanded', String(!isOpen));
      document.body.style.overflow = isOpen ? '' : '';
    });

    // Close drawer on link click
    drawer.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        drawer.classList.remove('open');
        toggle.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });

    // Close on outside click
    document.addEventListener('click', e => {
      if (!nav.contains(e.target) && !drawer.contains(e.target)) {
        drawer.classList.remove('open');
        toggle.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // ── Intersection Observer for reveal animations ──
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.08 });

  document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

  // Immediately show anything already in viewport
  document.querySelectorAll('.reveal').forEach(el => {
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight) el.classList.add('visible');
  });


  // ── Nav v2: scroll state, progress bar, "Hire me" button ──
  const navEl = document.getElementById('main-nav');
  if (navEl) {
    const logo = navEl.querySelector('.nav-logo');
    const root = logo ? logo.getAttribute('href').replace('index.html', '') : '';
    const cta = root + 'pages/editing.html#hire';

    const ul = navEl.querySelector('.nav-links');
    if (ul && !ul.querySelector('.nav-cta')) {
      const li = document.createElement('li');
      li.innerHTML = '<a class="nav-cta" href="' + cta + '">' + (window.ico ? ico('film') : '') + ' Hire me</a>';
      ul.appendChild(li);
    }
    const dr = document.getElementById('nav-drawer');
    if (dr && !dr.querySelector('.nav-cta')) {
      const a = document.createElement('a');
      a.className = 'nav-cta'; a.href = cta; a.innerHTML = (window.ico ? ico('film') : '') + ' Hire me as an editor';
      dr.appendChild(a);
    }

    const bar = document.createElement('div');
    bar.className = 'nav-progress';
    navEl.appendChild(bar);
    const onScroll = () => {
      const h = document.documentElement;
      const max = h.scrollHeight - h.clientHeight;
      bar.style.width = (max > 0 ? (h.scrollTop / max) * 100 : 0) + '%';
      navEl.classList.toggle('scrolled', h.scrollTop > 80);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

});
