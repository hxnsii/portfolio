# Hansi Denise D. Dolores — Portfolio Website

A multi-page personal portfolio built with HTML, CSS, and JavaScript.
Deployed via GitHub Pages.

## 📁 Folder Structure

```
hansi-portfolio/
├── index.html          ← Homepage
├── css/
│   └── style.css       ← Shared styles (all pages use this)
├── js/
│   ├── main.js         ← Shared JS (nav active state + animations)
│   ├── videos.js       ← PUBLIC list of videos shown on the Editing page
│   └── editing.js      ← Editing page logic (add/upload videos, hire form)
├── pages/
│   ├── about.html      ← About Me page
│   ├── academic.html   ← Academic Background page
│   ├── skills.html     ← Skills page
│   ├── projects.html   ← Projects page (includes YouTube game embed + ParJuans PHP/SQL project)
│   ├── editing.html    ← Video editing: your reel, services, hire form
│   └── contact.html    ← Contact page
└── assets/             ← Put your photos/images here
    └── (your-photo.jpg)
```

## 🚀 Running Locally in WebStorm

1. Open WebStorm → **File → Open** → select the `hansi-portfolio` folder
2. Right-click `index.html` → **Open In → Browser** (or click the browser icon top-right of editor)
3. WebStorm will serve it with a local dev server — live reload included!

## 🌐 Deploying to GitHub Pages

1. Create a repo named: `yourusername.github.io`
2. Upload all files (keep the folder structure intact)
3. Go to repo **Settings → Pages → Source: main / root**
4. Your site will be live at: `https://yourusername.github.io`

## ✏️ Personalizing

- **Add your photo**: Put your photo in `assets/` folder, then replace the photo frame in `pages/about.html`:
  ```html
  <!-- Replace the .photo-frame div content with: -->
  <img src="../assets/your-photo.jpg" alt="Hansi Denise" style="width:100%; height:100%; object-fit:cover;">
  ```

- **Update email**: Search for `edibyhansi@gmail.com` and replace with your real email

- **Update GitHub link**: Search for `https://github.com` and replace with your real GitHub profile URL

- **Contact form (real emails)**: Sign up at formspree.io, get your endpoint, and replace the `sendMessage()` function with a fetch POST to your Formspree URL

## 🌸 Pages

| Page | File | Description |
|------|------|-------------|
| Home | `index.html` | Hero + quick nav cards |
| About | `pages/about.html` | Bio, chips, values |
| Academic | `pages/academic.html` | Education, awards, grade timeline |
| Skills | `pages/skills.html` | Languages, tools, learning |
| Projects | `pages/projects.html` | Game video + project cards |
| Editing | `pages/editing.html` | Video reel, services, hire form |
| Contact | `pages/contact.html` | Form + social links |

Note: visit counters were removed (no `backend.js`).
